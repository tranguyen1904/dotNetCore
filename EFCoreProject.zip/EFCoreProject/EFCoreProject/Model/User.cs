﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace EFCoreProject.Model
{
    public class User
    {
        [Key]
        public Guid Id { get; set; }
        public string Nickname { get; set; }
        public string Mail { get; set; }
        [NotMapped]
        public string LoginSession { get; set; }
    }
}
