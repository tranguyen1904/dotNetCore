﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx4
{
    public abstract class Animal: ISound
    {
        public byte Age { get; set; }
        public string Name { get; set; }
        public string Sex { get; set; }

        public Animal(byte age, string name, string sex)
        {
            Age = age;
            Name = name;
            Sex = sex;
        }

        public override string ToString()
        {
            return $"Name: {Name}, Sex: {Sex}, Age: {Age}";
        }

        public abstract string MakeSound();
        
        public static double AverageAge(List<Animal> animals)
        {
            return animals.Average(x => x.Age);
        }
    }
}
