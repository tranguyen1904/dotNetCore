﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx4
{
    public class Kitten : Cat
    {
        public Kitten(byte age, string name) : base(age, name, "Female")
        {
        }

        public override string MakeSound()
        {
            return "Kitten sound";
        }
    }
}
