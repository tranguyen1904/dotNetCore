﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx4
{
    public static class AnimalTest
    {
        public static void Testing()
        {
            Cat[] cats = new Cat[]
            {
                new Cat(5, "Tom", "Male"),
                new Cat(3, "Orgy", "Male"),
                new Cat(3, "Mickey", "Male"),
            };
            Console.WriteLine("Average age of cats is " + Animal.AverageAge(cats.Cast<Animal>().ToList())); ;
            Dog[] dogs = new Dog[]
            {
                new Dog(4, "Nasus", "Male"),
                new Dog(3, "Warwick", "Male"),
                new Dog(7, "Scooby Doo", "Male")
            };
            Console.WriteLine("Average age of dogs are " + Animal.AverageAge(dogs.Cast<Animal>().ToList()));
            

            Frog[] frogs = new Frog[]
            {
                new Frog(1, "Froggy", "FeMale"),
                new Frog(3, "Tamken", "Male"),
                new Frog(4, "MilkTea", "Male")
            };
            Console.WriteLine("Average age of frogs is " + Animal.AverageAge(frogs.Cast<Animal>().ToList()));
        }
    }
}
