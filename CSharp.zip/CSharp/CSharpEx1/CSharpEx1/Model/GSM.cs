﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx1.Model
{
    class GSM
    {
        //Field
        public string model { get; set; }
        public string manufacturer { get; set; }
        public decimal? price { get; set; }
        public string owner { get; set; }
        public Battery Battery { get; set; }
        public Display Display { get; set; }
        public List<Call> CallHistory { get; set; }
        public string Model
        {
            get => this.model;
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("Model can not be null or empty.");
                }

                this.model = value;
            }
        }

        public string Manufacturer
        {
            get => this.manufacturer;
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("Manufacturer can not be null or empty.");
                }

                this.manufacturer = value;
            }
        }
        public decimal? Price
        {
            get => this.price;
            set
            {
                if (value!=null && value < 0)
                {
                    throw new ArgumentException("Price can not be a negative number.");
                }

                this.price = value;
            }
        }

        public string Owner
        {
            get => this.owner;
            set => this.owner = value;
        }

        public static GSM iPhone4S = new GSM("IPhone 4S", "Apple", 123, "", new Battery("Apple", 1, 1, Battery.BatteryType.LiPo), new Display(1200, 800, 100000));

        public static GSM IPhone4S => iPhone4S;

        // Constructor
        public GSM(string model, string manufacturer, decimal? price, string owner, Battery battery, Display display)
        {
            Model = model;
            Manufacturer = manufacturer;
            Price = price;
            Owner = owner;
            Battery = battery;
            Display = display;
            CallHistory = new List<Call>();
        }

        public GSM(string model, string manufacturer):this(model, manufacturer, null, null, null, null){}
        // Override ToString
        public override string ToString()
        {
            var result = "Model: " + Model
                                   + "\nManufacturer: " + Manufacturer
                                   + "\nPrice: " + Price
                                   + "\nOwner: " + Owner
                                   + "\nBattery: " + Battery?.ToString()
                                   + "\nDisplay: " + Display?.ToString();
            return result;
        }

        // Call
        public void AddCall(string phoneNumber, uint duration)
        {
            this.CallHistory.Add(new Call(phoneNumber, duration));
        }

        public void DeleteCall(int position)
        {
            if (position < 0 || position >= this.CallHistory.Count)
            {
                throw new Exception("Call position is not valid!");
            }
            this.CallHistory.RemoveAt(position);
        }

        public void ClearCallHistory()
        {
            this.CallHistory.Clear();
        }

        public double TotalCallPrice(double pricePerMinute)
        {
            uint totalDuration = 0;
            foreach (Call call in this.CallHistory)
            {
                totalDuration += call.Duration;
            }

            return totalDuration * pricePerMinute / 60;
        }

        public void displayCallHistory()
        {
            Console.WriteLine("----- Display Call History -----");
            foreach (Call call in CallHistory)
            {
                Console.WriteLine(call.ToString());
            }
        }
    }
}
