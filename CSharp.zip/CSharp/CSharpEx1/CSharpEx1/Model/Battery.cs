﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx1.Model
{
    class Battery
    {
        private string model;
        private uint? hoursIdle;
        private uint? hoursTalk;

        public string Model
        {
            get => this.model;
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The battery model can not be null or emtpy.");
                }
                this.model = value;
            }
        }

        public uint? HoursIdle
        {
            get => this.hoursIdle;
            set => this.hoursIdle = value;
        }

        public uint? HoursTalk
        {
            get => this.hoursTalk;
            set => this.hoursTalk = value;
        }
        public BatteryType? Type { get; set; }

        public enum BatteryType
        {
            LiIon,
            NiMH,
            NiCd,
            LiPo
        }

        public Battery(string model, uint? hoursIdle, uint? hoursTalk, BatteryType? type)
        {
            this.Model = model;
            this.HoursIdle = hoursIdle;
            this.HoursTalk = hoursTalk;
            this.Type = type;
        }

        public Battery(string model):this(model, null, null, null){}

        public override string ToString()
        {
            return "Model: " + Model
                             + "; HoursIdle: " + HoursIdle
                             + "; HoursTalk: " + HoursTalk
                             + "; Battery Type: " + Type?.ToString();
        }
    }
}
