﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx1.Model
{
    class Call
    {
        public DateTime CallingTime { get; set; }
        public string PhoneNumber { get; set; }
        public uint Duration { get; set; }

        public override string ToString()
        {
            return $"{this.PhoneNumber} : Duration - {this.Duration} , made on {this.CallingTime}";
        }

        public Call(string phoneNumber, uint duration)
        {
            this.CallingTime = DateTime.Now;
            this.PhoneNumber = phoneNumber;
            this.Duration = duration;
        }
    }
}
