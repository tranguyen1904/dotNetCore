﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSharpEx1.Model;
using CSharpEx1.Test;

namespace CSharpEx1
{
    class Program
    {
        static void Main(string[] args)
        {
            new GSMTest().Testing();
            // Console.WriteLine(new Battery("a").ToString());
            // Console.WriteLine(new Display().ToString());
            // Console.WriteLine(new GSM("a", "a").ToString());
            new GSMCallHistoryTest().Testing();
            Console.ReadKey();
        }
    }
}
