﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSharpEx1.Model;

namespace CSharpEx1.Test
{
    class GSMCallHistoryTest
    {
        public void Testing()
        {
            GSM gsm = new GSM("Redmi Note 7", "Xiaomi");
            gsm.AddCall("1234", 412);
            gsm.AddCall("0989213432", 342);
            gsm.AddCall("0989192194", 89);
            gsm.AddCall("078434", 24);

            //DIsplay call history
            
            gsm.displayCallHistory();

            Console.WriteLine($"Total call price: {gsm.TotalCallPrice(0.37)}");
            uint max = 0;
            int index = 0;
            for (int i = 0; i < gsm.CallHistory.Count; i++)
            {
                if (gsm.CallHistory[i].Duration > max)
                {
                    index = i;
                    max = gsm.CallHistory[i].Duration;
                }
            }
            Console.WriteLine();
            Console.WriteLine($"Remote Longest call");
            gsm.DeleteCall(index);
            Console.WriteLine($"Total call price: {gsm.TotalCallPrice(0.37)}");
            Console.WriteLine();
            Console.WriteLine("Clear call history");
            gsm.ClearCallHistory();
            gsm.displayCallHistory();

        }
    }
}
