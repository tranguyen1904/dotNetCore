﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSharpEx1.Model;

namespace CSharpEx1.Test
{
    class GSMTest
    {
        List<GSM> ListGSMs = new List<GSM>();

        public void CreateGSMs()
        {
            ListGSMs.Add(new GSM("Redmi Note 7", "Xiaomi", 4000000, "Trang Uyen", 
                new Battery("Unknown", 1,1, Battery.BatteryType.LiPo), 
                new Display(1200, 800, 1000)));
            ListGSMs.Add(new GSM("Galaxy Note 8", "Samsung"));
            ListGSMs.Add(new GSM("Nokia 1080", "Nokia", 1000000000, "Trang Uyen",
                new Battery("Nuclear", 1000, 1000, Battery.BatteryType.LiPo),
                new Display(800, 300, 1600000)));
        }

        public void DisplayGSMs()
        {
            Console.WriteLine("----- Display GSM -----");
            foreach (GSM phone in ListGSMs)
            {
                Console.WriteLine(phone.ToString());
                Console.WriteLine();
            }
        }

        public void DisplayIPhone4S()
        {
            Console.WriteLine("----- Display IPhone4s -----");
            Console.WriteLine(GSM.IPhone4S.ToString());
            Console.WriteLine();
        }

        public void Testing()
        {
            CreateGSMs();
            DisplayGSMs();
            
            DisplayIPhone4S();
        }
    }
}
