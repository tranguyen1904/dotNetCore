﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx2
{
    public class Comment
    {
        private List<string> comments;

        public List<string> Comments
        {
            get => this.comments;
            set
            {
                if (value==null)
                    throw new Exception("Comments cannot be null");
                this.comments = value;
            }
        }

        public Comment()
        {
            comments = new List<string>();
        }
    }
}
