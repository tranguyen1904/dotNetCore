﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx2
{
    class Discipline: Comment
    {
        private string name;
        private int numberOfLectures;
        private int numberOfExercises;

        public string Name
        {
            get => this.name;
            set
            {
                if (value == null)
                {
                    throw new Exception("Discipline Name cannot be null");
                }
                else
                {
                    this.name = value;
                }
            }
        }

        public int NumberOfLectures
        {
            get => this.numberOfLectures;
            set => this.numberOfLectures = value;
        }

        public int NumberOfExercises
        {
            get => this.numberOfExercises;
            set => this.numberOfExercises = value;
        }

        public Discipline(string name, int numberOfLectures, int numberOfExercises)
        {
            this.name = name;
            this.numberOfLectures = numberOfLectures;
            this.numberOfExercises = numberOfExercises;
        }
    }
}
