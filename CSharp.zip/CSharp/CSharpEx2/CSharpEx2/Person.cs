﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx2
{
    public class Person: Comment
    {
        private string name;

        public string Name
        {
            get => this.name;
            set
            {
                if (value == null)
                {
                    throw new Exception("First name cannot be null!");
                }
                else
                {
                    this.name = value;
                }
            }
        }

        public Person(string name)
        {
            this.name = name;
        }
    }
}
