﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx2
{
    class Class: Comment
    {
        private List<Student> students;
        private List<Teacher> teachers;
        private string classID;

        public List<Student> Students
        {
            get => this.students;
            set => this.students = value;
        }

        public List<Teacher> Teachers
        {
            get => this.teachers;
            set => this.teachers = value;
        }

        public string ClassID
        {
            get => this.classID;
            set
            {
                if (value == null)
                {
                    throw new Exception("Class ID cannot be null!");
                }
                else
                {
                    this.classID = value;
                }
            }
        }

        public Class(List<Student> students, List<Teacher> teachers, string classId)
        {
            this.students = students;
            this.teachers = teachers;
            classID = classId;
        }
    }
}
