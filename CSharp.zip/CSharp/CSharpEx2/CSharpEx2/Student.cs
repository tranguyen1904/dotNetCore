﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx2
{
    public class Student: Person
    {
        private int classNumber;

        public int ClassNumber
        {
            get => classNumber;
            set
            {
                if (value <= 0)
                {
                    throw new Exception("Student class number must be > 0");
                }
                else
                {
                    this.classNumber = value;
                }
            }
        }

        public Student(string name, int classNumber) : base(name)
        {
            this.classNumber = classNumber;
        }
    }
}
