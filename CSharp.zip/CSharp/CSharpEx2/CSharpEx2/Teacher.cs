﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx2
{
    class Teacher: Person
    {
        private List<Discipline> disciplines;

        public List<Discipline> Disciplines
        {
            get => this.disciplines;
            set
            {
                if (value == null)
                {
                    throw new Exception("Discipline cannot be null!");
                }
                else
                {
                    this.disciplines = value;
                }
            }
        }

        public Teacher(string name, List<Discipline> disciplines) : base(name)
        {
            this.disciplines = disciplines;
        }
    }
}
