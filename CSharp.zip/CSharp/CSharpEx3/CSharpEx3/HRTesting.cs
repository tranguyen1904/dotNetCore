﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx3
{
    class HRTesting
    {
        public List<Student> Students = new List<Student>();
        public List<Worker> Workers = new List<Worker>();

        public void CreateStudents()
        {
            Students.Add(new Student("Trang", "Uyen", 12));
            Students.Add(new Student("Uyen", "Trang", 10));
            Students.Add(new Student("Thien", "Khai", 8));
            Students.Add(new Student("Khai", "Thien", 6));
            Students.Add(new Student("Thien", "Hau", 4));
            Students.Add(new Student("Hau", "Thien", 2));
            Students.Add(new Student("Moc", "Mien", 1));
            Students.Add(new Student("Moc", "Chau", 3));
            Students.Add(new Student("Moc", "Hy", 5));
            Students.Add(new Student("Moc", "Diem", 10));
        }

        public void CreateWorkers()
        {
            Workers.Add(new Worker("Thanh", "Uyen", 126, 4));
            Workers.Add(new Worker("Uyen", "Minh", 160, 5));
            Workers.Add(new Worker("Thien", "Ha", 48, 6));
            Workers.Add(new Worker("Khai", "Minh", 886, 7));
            Workers.Add(new Worker("Thanh", "Hau", 445, 8));
            Workers.Add(new Worker("Diep", "Pham", 42, 9));
            Workers.Add(new Worker("Khoi", "Nguyen", 81, 6));
            Workers.Add(new Worker("Diep", "Tinh", 843, 7));
            Workers.Add(new Worker("Thanh", "Thanh", 123, 4));
            Workers.Add(new Worker("An", "An", 150, 7));
        }

        public void SortListStudents()
        {
            var sortList = Students.OrderBy(s=>s.Grade);
            foreach (Student student in sortList)
            {
                Console.WriteLine( student.ToString());
            }
        }

        public void SortListWorkers()
        {
            var sortList = Workers.OrderByDescending(s => s.MoneyPerHour());
            foreach (Worker worker in sortList)
            {
                Console.WriteLine(worker.ToString());
            }
        }

        public void MergeThenSort()
        {
            List<Human> humen = new List<Human>();
            humen.AddRange(Students);
            humen.AddRange(Workers);
            var sortList = humen.OrderBy(c => c.FirstName).ThenBy(c => c.LastName);
            foreach (Human human in sortList)
            {
                Console.WriteLine(human.ToString());
            }
        }

        public void Testing()
        {
            CreateStudents();
            CreateWorkers();
            Console.WriteLine("-----Sorted List Students-----");
            SortListStudents();
            Console.WriteLine("-----Sorted List Workers-----");
            SortListWorkers();
            Console.WriteLine("-----Sorted Merge List-----");
            MergeThenSort();
        }
    }
}
