﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx3
{
    public abstract class Human
    {
        private string firstName;
        private string lastName;

        public string FirstName
        {
            get => this.firstName;
            set
            {
                if (value == null)
                {
                    throw new Exception("First Name cannot be null");
                }
                else
                {
                    this.firstName = value;
                }
            }
        }
        public string LastName
        {
            get => this.lastName;
            set
            {
                if (value == null)
                {
                    throw new Exception("Last Name cannot be null");
                }
                else
                {
                    this.lastName = value;
                }
            }
        }

        public Human(string firstName, string lastName)
        {
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public override string ToString()
        {
            return $"First Name: {firstName}; Last Name: {lastName}; ";
        }
    }
}
