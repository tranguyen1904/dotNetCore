﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx3
{
    class Worker:Human
    {
        private decimal weekSalary;
        private int workHoursPerDay;

        public decimal WeekSalary
        {
            get => this.weekSalary;
            set
            {
                if (value < 0)
                {
                    throw new Exception("Salary cannot be < 0");
                }
                else
                {
                    this.weekSalary = value;
                }
            }
        }

        public int WorkHoursPerDay
        {
            get => this.workHoursPerDay;
            set
            {
                if (value <= 0)
                {
                    throw new Exception("Work Hours per Day cannot be <= 0");
                }
                else
                {
                    this.weekSalary = value;
                }
            }
        }

        public Worker(string firstName, string lastName, decimal weekSalary, int workHoursPerDay) : base(firstName, lastName)
        {
            this.weekSalary = weekSalary;
            this.workHoursPerDay = workHoursPerDay;
        }

        public decimal MoneyPerHour()
        {
            return decimal.Round(weekSalary / workHoursPerDay / 5, 3);
        }

        public override string ToString()
        {
            return base.ToString()+$"Week salary: {weekSalary}; Work hours per day: {workHoursPerDay}; Money per hour: {MoneyPerHour()}";
        }
    }
}
