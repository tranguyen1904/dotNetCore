﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEx3
{
    class Student: Human
    {
        private int grade;

        public int Grade
        {
            get => this.grade;
            set
            {
                if (value < 1 || value > 12)
                {
                    throw new Exception("Grade in the range 1-12!");
                }
                else
                {
                    this.grade = value;
                }
            }
        }

        public Student(string firstName, string lastName, int grade) : base(firstName, lastName)
        {
            this.grade = grade;
        }

        public override string ToString()
        {
            return base.ToString()+$"Grade: {grade}";
        }
    }
}
